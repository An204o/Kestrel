# Series A Pitch Deck Outline — Kestrel Logic (Fictional)

Target length: 12 slides, 15 minutes. Figures are fictional.

| # | Slide | Key message | Content |
|---|---|---|---|
| 1 | Title | Answers your operations team can trust | Logo, tagline, presenter |
| 2 | Problem | Operations teams lose hours navigating ERP screens | 3 example questions; time lost per planner per week |
| 3 | Why now | LLMs make natural-language access to structured data practical | Capability shift; mid-market has no in-house AI team |
| 4 | Solution | Grounded answers with citations | Product screenshot: question, answer, source links |
| 5 | How it works | Retrieve, ground, verify, then answer | Pipeline diagram; abstain-when-unsure principle |
| 6 | Product depth | Workflow agents with human approval | Late-shipment alert and PO follow-up demo |
| 7 | Market | About 40,000 target companies | Bottom-up sizing: companies x seats x price |
| 8 | Traction | 41 customers, about $2.2M ARR | ARR growth chart; plan mix; retention |
| 9 | Business model | Per-seat plus metered usage | Pricing tiers; inference cost under 12% of revenue |
| 10 | Competition | Deep ERP grounding is the gap | 2x2: ERP-aware vs. cited and safe; competitors placed fairly |
| 11 | Team | AI platform, ERP, and enterprise sales experience | Leadership bios; org snapshot |
| 12 | The ask | $6M Series A | Use of funds; milestones for next 18 months |

## Speaker notes: slide 5 (the technical credibility slide)
- We retrieve before we generate, and we skip the model call entirely when evidence is weak.
- Every answer is checked: citations must point at records that were actually retrieved.
- Every release is gated by a regression evaluation on a golden question set.
- Cost control is built in: response caching, tiered models, and spend caps.

## Likely investor questions
1. How do you prevent hallucinations? (Cite-or-abstain, citation verification, nightly evals.)
2. What stops ERP vendors from bundling this? (Depth across multiple ERPs, workflow safety, evaluation tooling.)
3. How do inference costs scale? (Caching, abstaining early, model routing, per-tenant caps.)
