# Website Copy — kestrellogic.example (Fictional)

## Home

### Hero
**Answers your operations team can trust.**
Ask about orders, inventory, and suppliers in plain English. Kestrel Assist answers from your own ERP data and shows the records behind every answer.

[Book a demo] [See how it works]

### Three-up
**Ask anything.** "Which open orders are at risk because of the resin shortage?" Get an answer in seconds, not a spreadsheet export.

**See the proof.** Every answer links to the order, part, or procedure it came from. If we can't find support, we say so.

**Stay in control.** Draft purchase-order follow-ups and late-shipment notices with one click. Nothing is sent until a person approves it.

### Social proof (fictional)
"Our customer service team stopped bouncing between four screens to answer a delivery question." — Operations Director, mid-size plastics manufacturer

### How it works
1. **Connect** your ERP and document library.
2. **Ask** questions in chat or inside the tools your team already uses.
3. **Verify** with source links, then approve any suggested action.

### Call to action
Ready to see it on your own data? [Book a 30-minute demo]

---

## Pricing

| | Starter | Growth | Enterprise |
|---|---|---|---|
| Price | $45 / user / month | $70 / user / month | Custom |
| Users | Up to 25 | Unlimited | Unlimited |
| Assistant queries | 2,000 / month | Pooled by team | Custom |
| Workflow agents | — | Included | Included |
| SSO and audit export | — | — | Included |
| Data residency options | — | — | Included |

*All prices and plans are fictional.*

---

## Security (short form)
Your data is isolated per customer, encrypted in transit and at rest, and never used to train shared models. Every AI action is logged and every write requires approval.

## FAQ
**Does Kestrel Assist make things up?** It is built to cite or abstain. Answers must reference your records; when evidence is weak, it tells you instead of guessing.

**Which ERP systems do you support?** Two connectors are available today, with more on the roadmap.

**Can we cap what it costs?** Yes. Set monthly query budgets per team and get alerts before you reach them.
