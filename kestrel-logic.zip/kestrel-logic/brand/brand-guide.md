# Kestrel Logic — Brand Guide (Fictional)

## Positioning
**Tagline:** Answers your operations team can trust.
**Short description:** Kestrel Assist is the AI assistant that answers questions about your orders, inventory, and suppliers, and shows its sources.
**Personality:** precise, practical, calm. We sound like a veteran operations manager, not a hype-filled startup.

## Voice and tone
| Do | Avoid |
|---|---|
| Use plain operations language: orders, lead times, backorders | Buzzwords such as "revolutionary" or "game-changing" |
| Quantify claims (for example, "cites every answer") | Vague promises ("10x productivity") |
| Admit limits: "I don't have enough information" | Sounding certain when evidence is weak |
| Short sentences, active voice | Jargon-heavy AI explanations for business readers |

## Color palette
| Name | Hex | Use |
|---|---|---|
| Kestrel Navy | `#0B2545` | Primary text, logo mark, headers |
| Signal Teal | `#13A89E` | Links, highlights, secondary logo stroke |
| Wing Amber | `#F2A541` | Calls to action, accents (use sparingly) |
| Fog | `#F4F6F8` | Page backgrounds |
| Slate | `#5B6770` | Secondary text |

Contrast note: Navy on Fog passes WCAG AA for body text. Do not place Slate text on Amber, and do not use Teal or Amber for small body text on white.

## Typography
- Headings: Helvetica Neue / Arial, bold
- Body: system sans-serif stack, 16 px minimum on web
- Code and data: monospace

## Logo usage
- Files: `logo.svg` (full lockup).
- Keep clear space equal to the height of the "K" on all sides.
- Minimum width: 120 px.
- Do not recolor the strokes, stretch the mark, or place it on busy imagery.

## Messaging pillars
1. **Grounded.** Every answer links to the records behind it.
2. **Efficient.** Fast answers and predictable costs, with spend caps per team.
3. **Safe.** Actions are drafted for approval and every step is audited.
