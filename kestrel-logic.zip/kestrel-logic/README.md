# Kestrel Logic (Hypothetical Company)

A fictional enterprise AI software company that sells **Kestrel Assist**, a grounded AI assistant for manufacturers and distributors. Everything here is invented for portfolio and practice use.

| Folder | Contents |
|---|---|
| `business-docs/` | One-pager, business plan, org chart and roles, AI safety and data policy |
| `data/` | Synthetic CSVs and one combined `.xlsx` (customers, suppliers, parts, inventory, orders, support tickets, employees) plus the seeded generator script |
| `kestrel-assist/` | Working Python RAG service with tests (29), golden-set eval, and design notes. Start with its README |
| `brand/` | Brand guide, SVG logo, website copy, pitch deck outline |

Headline figures line up across files: 41 customers and about $2.2M ARR match the sample `customers.csv`, and the roughly 40-person team matches `employees.csv` (department counts there are approximate and differ slightly from the org chart).
