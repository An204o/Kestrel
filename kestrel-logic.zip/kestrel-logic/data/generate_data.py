"""Generate fictional sample data for Kestrel Logic.

Usage: python3 generate_data.py [output_dir]
All data is synthetic and seeded for reproducibility.
"""
from __future__ import annotations

import csv
import random
import sys
from datetime import date, timedelta
from pathlib import Path

SEED = 42
rng = random.Random(SEED)

FIRST = ["Ava", "Liam", "Noor", "Mateo", "Priya", "Ethan", "Sofia", "Kofi", "Yara", "Lucas", "Mina", "Omar",
         "Elena", "Jamal", "Hana", "Ivan", "Chloe", "Arjun", "Leila", "Marcus"]
LAST = ["Nguyen", "Patel", "Garcia", "Kim", "Okafor", "Silva", "Novak", "Haddad", "Brooks", "Tanaka",
        "Ivanov", "Rossi", "Cohen", "Mensah", "Larsen", "Reyes", "Aliyev", "Chen", "Dubois", "Khan"]
STATES = ["FL", "GA", "TX", "OH", "MI", "NC", "TN", "IL", "PA", "WI"]
INDUSTRIES = ["Metal Fabrication", "Plastics", "Food Packaging", "Industrial Distribution", "Electronics Assembly",
              "Building Materials", "Automotive Components", "Medical Supplies"]
COMPANY_A = ["Summit", "Harbor", "Ironwood", "Bluepeak", "Cobalt", "Redline", "Evergreen", "Falcon", "Granite",
             "Meridian", "Northgate", "Oakridge", "Pioneer", "Quarry", "Riverbend", "Sterling", "Titan", "Union"]
COMPANY_B = ["Fabrication", "Plastics", "Supply", "Components", "Packaging", "Industries", "Distribution",
             "Manufacturing", "Materials", "Works"]


def name() -> str:
    return f"{rng.choice(FIRST)} {rng.choice(LAST)}"


def write_csv(path: Path, header: list[str], rows: list[list]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def main(out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    today = date(2026, 11, 1)

    # Customers (Kestrel Logic's paying accounts)
    used = set()
    customers = []
    for i in range(1, 42):
        while True:
            cname = f"{rng.choice(COMPANY_A)} {rng.choice(COMPANY_B)}"
            if cname not in used:
                used.add(cname)
                break
        plan = rng.choices(["Starter", "Growth", "Enterprise"], weights=[50, 35, 15])[0]
        seats = {"Starter": rng.randint(5, 25), "Growth": rng.randint(20, 120), "Enterprise": rng.randint(100, 600)}[plan]
        price = {"Starter": 45, "Growth": 70, "Enterprise": 60}[plan]
        customers.append([
            f"C{i:03d}", cname, rng.choice(INDUSTRIES), rng.choice(STATES), plan, seats,
            seats * price * 12, (today - timedelta(days=rng.randint(30, 700))).isoformat(),
        ])
    write_csv(out / "customers.csv",
              ["customer_id", "company", "industry", "state", "plan", "seats", "annual_contract_value_usd", "start_date"],
              customers)

    # Suppliers
    suppliers = []
    for i in range(1, 16):
        suppliers.append([
            f"S{i:03d}", f"{rng.choice(COMPANY_A)} {rng.choice(COMPANY_B)} Co.", rng.choice(STATES + ["MX", "CA"]),
            rng.randint(7, 45), round(rng.uniform(0.82, 0.99), 2),
        ])
    write_csv(out / "suppliers.csv",
              ["supplier_id", "supplier_name", "region", "avg_lead_time_days", "on_time_rate"], suppliers)

    # Parts and inventory
    categories = ["Fasteners", "Resin", "Steel Stock", "Packaging", "Circuit Boards", "Seals", "Motors"]
    parts, inventory = [], []
    for i in range(1, 61):
        pid = f"KL-{4000 + i}"
        cat = rng.choice(categories)
        cost = round(rng.uniform(0.4, 180.0), 2)
        sup = rng.choice(suppliers)[0]
        parts.append([pid, f"{cat} item {i}", cat, cost, sup])
        on_hand = rng.randint(0, 2500)
        reorder = rng.randint(100, 800)
        inventory.append([pid, on_hand, reorder, "BELOW_REORDER" if on_hand < reorder else "OK"])
    write_csv(out / "parts.csv", ["part_id", "description", "category", "unit_cost_usd", "primary_supplier_id"], parts)
    write_csv(out / "inventory.csv", ["part_id", "on_hand", "reorder_point", "status"], inventory)

    # Orders
    orders = []
    for i in range(1, 501):
        placed = today - timedelta(days=rng.randint(0, 120))
        promised = placed + timedelta(days=rng.randint(5, 30))
        status = rng.choices(["Shipped", "Open", "Backordered", "Cancelled"], weights=[60, 25, 10, 5])[0]
        delivered = ""
        if status == "Shipped":
            delivered = (promised + timedelta(days=rng.randint(-3, 6))).isoformat()
        part = rng.choice(parts)[0]
        orders.append([
            f"SO-{10000 + i}", rng.choice(customers)[0], part, rng.randint(10, 2000), placed.isoformat(),
            promised.isoformat(), delivered, status,
        ])
    write_csv(out / "orders.csv",
              ["order_id", "customer_id", "part_id", "quantity", "placed_date", "promised_date", "delivered_date", "status"],
              orders)

    # Support tickets
    topics = ["Wrong answer cited", "Slow response", "Missing records in search", "SSO login issue",
              "Agent draft needs edit", "Usage report question", "Connector sync delay"]
    tickets = []
    for i in range(1, 201):
        opened = today - timedelta(days=rng.randint(0, 90))
        sev = rng.choices(["Low", "Medium", "High", "Critical"], weights=[45, 35, 15, 5])[0]
        hours = round(rng.uniform(0.5, 72.0), 1)
        tickets.append([
            f"T-{2000 + i}", rng.choice(customers)[0], rng.choice(topics), sev, opened.isoformat(),
            hours, rng.randint(1, 5),
        ])
    write_csv(out / "support_tickets.csv",
              ["ticket_id", "customer_id", "topic", "severity", "opened_date", "hours_to_resolve", "csat_1_to_5"], tickets)

    # Employees (38)
    depts = [("AI Platform", 8), ("Product Engineering", 9), ("Data and Analytics", 4), ("Platform and Security", 4),
             ("Product", 5), ("Customer Success", 6), ("Sales", 4)]
    employees, n = [], 1
    for dept, count in depts:
        for _ in range(count):
            employees.append([
                f"E{n:03d}", name(), dept,
                (date(2024, 1, 15) + timedelta(days=rng.randint(0, 900))).isoformat(),
            ])
            n += 1
    write_csv(out / "employees.csv", ["employee_id", "name", "department", "start_date"], employees)

    # Combined workbook
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
    except ImportError:
        print("openpyxl not installed; skipping workbook")
        return
    wb = Workbook()
    wb.remove(wb.active)
    for csv_path in sorted(out.glob("*.csv")):
        ws = wb.create_sheet(csv_path.stem[:31])
        with csv_path.open(encoding="utf-8") as f:
            for row_idx, row in enumerate(csv.reader(f), start=1):
                ws.append([_coerce(v) for v in row] if row_idx > 1 else row)
        for cell in ws[1]:
            cell.font = Font(bold=True)
        ws.freeze_panes = "A2"
        for col in ws.columns:
            width = max(len(str(c.value)) if c.value is not None else 0 for c in col)
            ws.column_dimensions[col[0].column_letter].width = min(width + 2, 40)
    wb.save(out / "kestrel_logic_sample_data.xlsx")


def _coerce(v: str):
    try:
        return int(v)
    except ValueError:
        try:
            return float(v)
        except ValueError:
            return v


if __name__ == "__main__":
    main(Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent)
