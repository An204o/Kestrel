# Kestrel Logic — Company One-Pager

*Hypothetical company created for portfolio and practice purposes. All names, figures, and customers are fictional.*

## What we do
Kestrel Logic builds **Kestrel Assist**, an AI assistant for mid-market manufacturers and distributors. It answers questions about orders, inventory, suppliers, and production schedules in plain English, grounded in the customer's own ERP data, and cites the records behind every answer.

## The problem
Planners, customer-service reps, and buyers at manufacturing and distribution companies spend hours each day navigating ERP screens and exporting spreadsheets to answer questions like:

- "Which open orders are at risk because of the resin shortage?"
- "What is the lead time on part KL-4410 from our second supplier?"
- "Why did on-time delivery drop in Q3?"

Generic chatbots hallucinate on this data. ERP search is keyword-only and requires knowing where to look.

## Our solution
| Capability | What it does |
|---|---|
| Grounded Q&A (RAG) | Retrieves relevant ERP records and documents, answers only from them, and cites sources |
| Workflow agents | Drafts purchase-order follow-ups, flags late shipments, and proposes reorder quantities, always with human approval |
| Intelligent search | Hybrid keyword and semantic search across parts, orders, suppliers, and SOP documents |
| Quality and cost controls | Built-in evaluation, response caching, model routing, and per-tenant spend caps |

## Target customers
Mid-market manufacturers and distributors (100-2,000 employees) running a mainstream ERP. Primary users are demand planners, buyers, customer-service teams, and operations managers.

## Business model
Per-seat subscription plus metered usage:

- **Starter:** $45 per user per month, up to 25 users, 2,000 assistant queries per month included
- **Growth:** $70 per user per month, workflow agents included
- **Enterprise:** custom pricing, dedicated tenant, SSO, audit export, data-residency options

## Differentiators
1. **Grounding first.** Every answer links to the underlying records. If retrieval confidence is low, the assistant says so rather than guessing.
2. **Cost discipline.** Semantic caching and tiered model routing keep inference cost under 12% of revenue.
3. **Safe automation.** Agents act through scoped, audited tool permissions and require approval for any write action.

## Snapshot (fictional)
- Founded: 2024
- Headquarters: Tampa, FL (remote-friendly)
- Team: about 40 people
- Customers: 41 paying accounts
- ARR: $2.2M
