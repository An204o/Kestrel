# Kestrel Logic — AI Safety and Data Handling Policy (Fictional Draft)

## 1. Principles
1. **Ground or abstain.** Answers must be supported by retrieved customer records. If support is insufficient, the assistant says it does not know.
2. **Least privilege.** The assistant and agents only access data the requesting user is authorized to see.
3. **Human approval for writes.** Agents may draft actions; a person approves anything that changes data or contacts a third party.
4. **Measure everything.** Quality, latency, cost, and failures are logged and reviewed weekly.

## 2. Data handling
| Topic | Policy |
|---|---|
| Tenant isolation | Separate indexes and encryption keys per tenant; no cross-tenant retrieval |
| Training | Customer data is never used to train or fine-tune shared models |
| Retention | Prompts and responses retained 30 days by default for debugging; configurable down to zero |
| PII | Detected and masked in logs; excluded from caches unless the tenant opts in |
| Vendors | LLM providers must offer zero-retention terms and regional hosting |

## 3. Release gates for AI features
- Passes regression evaluation (groundedness at or above 0.90, citation accuracy at or above 0.95 on the golden set)
- Latency p95 under 6 seconds on staging load test
- Cost per query within budget set at design review
- Monitoring dashboards and alerts live; runbook reviewed by on-call
- Rollout plan: internal, then 5% of tenants, then 25%, then general availability

## 4. Incident response
Severity 1 (wrong data shown across tenants, unsafe action executed): disable the feature flag immediately, notify affected customers within 24 hours, publish a post-incident review within 5 business days.
