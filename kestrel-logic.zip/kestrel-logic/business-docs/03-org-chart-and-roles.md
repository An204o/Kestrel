# Kestrel Logic — Org Chart and Roles (Fictional)

```
CEO — Dana Okafor
├── CTO — Rafael Mendes
│   ├── AI Platform (8): LLM gateway, RAG, evaluation, cost controls
│   ├── Product Engineering (9): web app, APIs, connectors
│   ├── Data and Analytics (4)
│   └── Platform / SRE and Security (4)
├── VP Product — Mei Lin Zhao
│   ├── Product Managers (3)
│   └── UX Design (2)
├── VP Customer Success — Tomas Havel
│   ├── Solutions Engineers (3)
│   └── Support (3)
└── VP Sales and Partnerships — Aisha Rahman
    └── Account Executives (3)
```

## AI Platform team (8)
| Role | Count | Focus |
|---|---|---|
| Staff AI Engineer | 1 | Architecture, model selection, cost-quality trade-offs |
| Mid-level AI Software Developer | 4 | RAG pipelines, agent workflows, service integrations |
| Evaluation Engineer | 1 | Golden sets, regression evals, telemetry analysis |
| Junior AI Developer / Intern | 2 | Connectors, tests, tooling, runbooks |

## Working agreements
- Every AI feature ships with tests, an evaluation set, monitoring, and a runbook.
- Code review required for all merges; at least one reviewer from outside the author's squad for security-sensitive changes.
- Weekly cost and quality review: latency, cost per query, thumbs-up rate, abstention rate.
- Sprints are two weeks; releases are feature-flagged and rolled out by tenant cohort.
