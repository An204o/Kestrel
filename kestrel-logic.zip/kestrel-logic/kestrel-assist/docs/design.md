# Design Notes and Runbook

## Request flow

```
question
  -> validate (non-empty, length cap)
  -> cache lookup (tenant, index version, normalized question)  --hit--> return, cost 0
  -> BM25 retrieve top_k from the tenant's index
  -> best chunk covers < min_coverage of query terms?  --yes--> abstain, no LLM call
  -> LLM call with numbered context and a "cite or refuse" system prompt
  -> citations all point at retrieved chunks?          --none valid--> abstain (ungrounded), not cached
  -> cache, record telemetry, return answer + citations + usage
```

## Key trade-offs

**Abstain before the LLM call.** Weak retrieval is the main source of hallucination, and a refusal costs nothing. The cost is lower recall on oddly phrased questions; tune `min_coverage` against the golden set, and track the abstain rate in production.

**Coverage instead of raw BM25 score as the confidence signal.** BM25 scores depend on corpus size and vocabulary, so a fixed threshold drifts as documents change. The fraction of query terms found is corpus-independent and easy to explain to non-technical stakeholders.

**Citation verification, not trust.** The service accepts a citation only if it names a chunk that was actually in the prompt. This catches fabricated references but not a correct citation attached to an unsupported claim; closing that gap needs an LLM-as-judge or entailment check, which adds latency and cost.

**Do not cache failures.** Ungrounded results are not cached, so a transient bad generation is retried instead of being served for an hour. Failed calls are still counted in cost telemetry.

**Cache invalidation by index version.** Re-indexing a tenant changes the cache key, so stale answers disappear without a flush.

## Quality, latency, and cost levers (in the order I would pull them)

1. Fix retrieval (chunking, hybrid search, reranking) using the golden set; most "model" quality problems are retrieval problems.
2. Cache and abstain early; both remove calls entirely.
3. Route easy questions to a smaller model; escalate on low confidence.
4. Trim context: lower `top_k`, shorter chunks, and drop low-scoring chunks.
5. Only then consider a larger model.

## Runbook

| Symptom | Check | Action |
|---|---|---|
| Abstain rate jumps | `/metrics` outcomes; recent index changes | Confirm documents indexed; check for a chunking regression; rerun the eval |
| `abstained_ungrounded` rising | Model or prompt change | Roll back the model or prompt; inspect sample outputs |
| Cost per request rising | Cache hit rate; average input tokens | Look for a larger `top_k` or chunk size; check for cache invalidation churn |
| p95 latency rising | Provider latency vs. local retrieval time | Add timeouts and retries with backoff at the client; consider a faster model |
| Wrong answer reported | Reproduce with the same question; find the cited chunk | Fix the source document or chunking; add the case to `eval/golden.jsonl` |

## Release gate

Before shipping a change to prompts, models, chunking, or retrieval: run `python -m kestrel_assist eval` (exits non-zero when citation hit rate drops below 0.95 or any unanswerable question is answered), then roll out behind a flag by tenant cohort.
