# Quality Hold Procedure

Any lot that fails incoming inspection is placed on quality hold and cannot be issued to production. The inspector tags the lot and records the failure code in the system.

The quality manager reviews held lots within 2 business days. Possible dispositions are release, rework, return to supplier, or scrap.

Scrap decisions above $5,000 require sign-off from the plant manager.
