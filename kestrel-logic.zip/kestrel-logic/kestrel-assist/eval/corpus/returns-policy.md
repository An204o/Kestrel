# Returns and Credits Policy

Customers may return unused items within 30 days of delivery for a full credit. Items must be in original packaging.

Custom-fabricated parts are non-returnable unless they fail inspection. Failed-inspection returns are credited in full, including freight.

Credits are issued to the customer's account within 5 business days after the returned items are received and inspected.

Returns over $10,000 require written approval from the Director of Customer Operations.
