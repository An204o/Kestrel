# Supplier Lead Times

The standard lead time for resin from Harbor Plastics Supply is 21 days. Expedited resin orders ship in 9 days with a 12 percent surcharge.

Steel stock from Granite Materials Co. has a standard lead time of 14 days. Orders placed after the 15th of the month ship in the following cycle.

Circuit boards sourced from Monterrey have a lead time of 35 days. Buyers should place circuit board orders at least 45 days before the required date.
