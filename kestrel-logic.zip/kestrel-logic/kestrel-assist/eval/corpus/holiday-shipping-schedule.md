# Holiday Shipping Schedule

The warehouse is closed on Thanksgiving Day, Christmas Day, and New Year's Day. No shipments leave on those dates.

The last day to place an order for delivery before Christmas is December 18. Orders placed after that date ship on January 2.

Expedited freight is available through December 22 for an additional fee of $85 per shipment.
