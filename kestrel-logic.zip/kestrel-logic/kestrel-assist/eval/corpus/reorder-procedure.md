# Reorder Procedure

A part is flagged BELOW_REORDER when its on-hand quantity drops under its reorder point. Buyers review the flagged list every Monday morning.

The default reorder quantity equals 4 weeks of average demand. Buyers may adjust the quantity but must record the reason in the purchase order notes.

Purchase orders above $25,000 require approval from the Operations Manager before release to the supplier.
