# Late Shipment Escalation

A shipment is late when the delivered date is after the promised date. Customer service must notify the customer within 1 business day of identifying a late shipment.

Shipments more than 5 days late are escalated to the Operations Manager. The escalation record must include the root cause and a revised delivery date.

Customers with Enterprise contracts receive a service credit of 2 percent of the order value for each full week of delay, up to 10 percent.
