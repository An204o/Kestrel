from __future__ import annotations

import json
import threading
import urllib.error
import urllib.request

import pytest

from kestrel_assist import AssistantService
from kestrel_assist.corpus import load_documents
from kestrel_assist.evaluation import load_cases, run_eval
from kestrel_assist.llm import ExtractiveFakeLLM
from kestrel_assist.server import create_server

from .conftest import CORPUS_DIR, GOLDEN


@pytest.fixture
def base_url(service):
    server = create_server(service, port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{server.server_address[1]}"
    server.shutdown()
    server.server_close()
    thread.join(timeout=5)


def _post(url: str, body: bytes) -> tuple[int, dict]:
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.status, json.load(resp)
    except urllib.error.HTTPError as err:
        return err.code, json.load(err)


def test_healthz(base_url):
    with urllib.request.urlopen(f"{base_url}/healthz", timeout=5) as resp:
        assert json.load(resp) == {"status": "ok"}


def test_ask_returns_grounded_answer(base_url):
    body = json.dumps({"tenant_id": "acme", "question": "How many days do customers have to return unused items?"})
    status, payload = _post(f"{base_url}/v1/ask", body.encode())
    assert status == 200
    assert payload["citations"] == ["returns#0"]
    assert payload["abstained"] is False


@pytest.mark.parametrize(
    ("body", "expected"),
    [
        (b"not json", 400),
        (json.dumps({"tenant_id": "acme"}).encode(), 400),
        (json.dumps({"tenant_id": 1, "question": "hi"}).encode(), 400),
        (json.dumps({"tenant_id": "nobody", "question": "hello there"}).encode(), 404),
        (json.dumps({"tenant_id": "acme", "question": "   "}).encode(), 422),
    ],
)
def test_bad_requests_get_clean_errors(base_url, body, expected):
    status, payload = _post(f"{base_url}/v1/ask", body)
    assert status == expected
    assert "error" in payload


def test_golden_set_meets_release_gate():
    """Mirrors the release gate in the safety policy: regressions here should block a deploy."""
    service = AssistantService(ExtractiveFakeLLM())
    service.index_documents("demo", load_documents(CORPUS_DIR))
    report = run_eval(service, "demo", load_cases(GOLDEN))
    assert report["failures"] == []
    assert report["citation_hit_rate"] >= 0.95
    assert report["abstain_accuracy"] == 1.0
