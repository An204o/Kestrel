from __future__ import annotations

import pytest

from kestrel_assist import AssistantService, Document, Settings, UnknownTenantError
from kestrel_assist.service import ABSTAIN_TEXT

from .conftest import CountingLLM, ScriptedLLM


def test_grounded_answer_cites_retrieved_chunk(service, llm):
    answer = service.ask("acme", "How many days do customers have to return unused items?")
    assert not answer.abstained
    assert answer.outcome == "answered"
    assert "30 days" in answer.text
    assert answer.citations == ("returns#0",)
    assert answer.usage.cost_usd > 0
    assert llm.calls == 1


def test_low_retrieval_abstains_without_calling_llm(service, llm):
    answer = service.ask("acme", "What is the warranty period for forklifts?")
    assert answer.abstained
    assert answer.text == ABSTAIN_TEXT
    assert answer.outcome == "abstained_low_retrieval"
    assert answer.usage.cost_usd == 0
    assert llm.calls == 0


def test_repeat_question_hits_cache_and_costs_nothing(service, llm):
    first = service.ask("acme", "How many days do customers have to return unused items?")
    second = service.ask("acme", "  how many DAYS do customers have to return unused items?  ")
    assert not first.cached and second.cached
    assert second.text == first.text
    assert second.usage.cost_usd == 0
    assert llm.calls == 1
    assert service.metrics.snapshot()["cache_hit_rate"] == 0.5


def test_reindexing_invalidates_cached_answers(service, llm):
    q = "How many days do customers have to return unused items?"
    service.ask("acme", q)
    service.index_documents("acme", [Document("returns", "Customers may return unused items within 60 days.")])
    answer = service.ask("acme", q)
    assert "60 days" in answer.text
    assert not answer.cached
    assert llm.calls == 2


def test_tenants_are_isolated(service, llm):
    service.index_documents("globex", [Document("secret", "Globex pays suppliers every 45 days.")])
    # "acme" must not see globex's document, and vice versa.
    assert service.ask("acme", "When does Globex pay suppliers?").abstained
    assert service.ask("globex", "How many days do customers have to return unused items?").abstained
    assert service.ask("globex", "When does Globex pay suppliers?").citations == ("secret#0",)


def test_answer_without_valid_citation_is_suppressed(docs):
    svc = AssistantService(ScriptedLLM("Returns are accepted for 90 days."))
    svc.index_documents("acme", docs)
    answer = svc.ask("acme", "How many days do customers have to return unused items?")
    assert answer.abstained
    assert answer.outcome == "abstained_ungrounded"
    assert answer.usage.cost_usd > 0  # the failed call is still paid for and must be reported
    # Ungrounded results must not be cached: the second call reaches the model again.
    assert not svc.ask("acme", "How many days do customers have to return unused items?").cached


def test_citation_to_chunk_not_in_context_is_rejected(docs):
    svc = AssistantService(ScriptedLLM("Returns take 90 days. [invented-doc#7]"))
    svc.index_documents("acme", docs)
    assert svc.ask("acme", "How many days do customers have to return unused items?").abstained


def test_input_validation(service):
    with pytest.raises(ValueError):
        service.ask("acme", "   ")
    with pytest.raises(ValueError):
        service.ask("acme", "x" * 5000)
    with pytest.raises(UnknownTenantError):
        service.ask("nobody", "hello there")


def test_unpriced_model_fails_fast():
    class Unpriced(CountingLLM):
        model = "mystery-model"

    with pytest.raises(ValueError, match="pricing"):
        AssistantService(Unpriced())


def test_settings_validation():
    with pytest.raises(ValueError):
        Settings(top_k=0)
    with pytest.raises(ValueError):
        Settings(min_coverage=0)


def test_metrics_snapshot_reflects_traffic(service):
    service.ask("acme", "How many days do customers have to return unused items?")
    service.ask("acme", "What is the warranty period for forklifts?")
    snap = service.metrics.snapshot()
    assert snap["requests"] == 2
    assert snap["outcomes"] == {"answered": 1, "abstained_low_retrieval": 1}
    assert snap["abstain_rate"] == 0.5
    assert snap["cost_usd"] > 0
