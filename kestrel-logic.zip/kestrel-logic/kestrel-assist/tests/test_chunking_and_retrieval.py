from __future__ import annotations

from kestrel_assist.chunking import chunk_document
from kestrel_assist.models import Document
from kestrel_assist.retrieval import BM25Index, tokenize


def test_chunks_are_one_paragraph_each_with_stable_ids():
    doc = Document("policy", "First paragraph.\n\nSecond paragraph.")
    chunks = chunk_document(doc)
    assert [c.chunk_id for c in chunks] == ["policy#0", "policy#1"]
    assert chunks[1].text == "Second paragraph."


def test_heading_stays_attached_to_following_paragraph():
    chunks = chunk_document(Document("d", "# Title\n\nBody text here."))
    assert len(chunks) == 1
    assert chunks[0].text.startswith("# Title")


def test_oversized_paragraph_is_split_within_limit():
    sentence = "This is a sentence of moderate length. "
    doc = Document("big", sentence * 40)
    chunks = chunk_document(doc, max_chars=200)
    assert len(chunks) > 1
    assert all(len(c.text) <= 200 for c in chunks)


def test_tokenize_drops_stopwords_and_plurals():
    assert tokenize("What are the Returns?") == ["return"]


def test_search_ranks_relevant_chunk_first():
    chunks = chunk_document(
        Document("a", "Resin lead time is 21 days.\n\nSteel ships from the plant weekly.\n\nInvoices are due in 30 days.")
    )
    results = BM25Index(chunks).search("resin lead time")
    assert results[0].chunk.chunk_id == "a#0"
    assert results[0].coverage == 1.0


def test_search_returns_nothing_for_stopword_only_or_unmatched_queries():
    index = BM25Index(chunk_document(Document("a", "Resin lead time is 21 days.")))
    assert index.search("what is the") == []
    assert index.search("forklift warranty") == []


def test_search_on_empty_index():
    assert BM25Index([]).search("anything") == []
