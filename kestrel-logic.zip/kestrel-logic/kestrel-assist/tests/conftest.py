from __future__ import annotations

from pathlib import Path

import pytest

from kestrel_assist import AssistantService, Document
from kestrel_assist.llm import Completion, ExtractiveFakeLLM

ROOT = Path(__file__).resolve().parents[1]
CORPUS_DIR = ROOT / "eval" / "corpus"
GOLDEN = ROOT / "eval" / "golden.jsonl"


class CountingLLM(ExtractiveFakeLLM):
    """Fake LLM that records how many times it was called."""

    def __init__(self) -> None:
        self.calls = 0

    def complete(self, system: str, user: str) -> Completion:
        self.calls += 1
        return super().complete(system, user)


class ScriptedLLM:
    """Returns a fixed string, to simulate misbehaving models."""

    model = "demo-small"

    def __init__(self, text: str) -> None:
        self._text = text

    def complete(self, system: str, user: str) -> Completion:
        return Completion(text=self._text, input_tokens=100, output_tokens=10)


@pytest.fixture
def docs() -> list[Document]:
    return [
        Document("returns", "# Returns\n\nCustomers may return unused items within 30 days of delivery."),
        Document("shipping", "# Shipping\n\nThe warehouse ships orders every weekday before 4 pm."),
    ]


@pytest.fixture
def llm() -> CountingLLM:
    return CountingLLM()


@pytest.fixture
def service(llm: CountingLLM, docs: list[Document]) -> AssistantService:
    svc = AssistantService(llm)
    svc.index_documents("acme", docs)
    return svc
