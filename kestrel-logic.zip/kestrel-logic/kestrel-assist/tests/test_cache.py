from __future__ import annotations

import pytest

from kestrel_assist.cache import TTLCache


class FakeClock:
    def __init__(self) -> None:
        self.now = 0.0

    def __call__(self) -> float:
        return self.now


def test_entries_expire_after_ttl():
    clock = FakeClock()
    cache: TTLCache[str] = TTLCache(ttl_seconds=10, clock=clock)
    cache.set("k", "v")
    clock.now = 9.9
    assert cache.get("k") == "v"
    clock.now = 10.0
    assert cache.get("k") is None
    assert len(cache) == 0


def test_least_recently_used_entry_is_evicted():
    cache: TTLCache[int] = TTLCache(max_entries=2)
    cache.set("a", 1)
    cache.set("b", 2)
    assert cache.get("a") == 1  # touch a, so b becomes least recently used
    cache.set("c", 3)
    assert cache.get("b") is None
    assert cache.get("a") == 1
    assert cache.get("c") == 3


def test_invalid_size_rejected():
    with pytest.raises(ValueError):
        TTLCache(max_entries=0)
