# Kestrel Assist

A small, dependency-free reference implementation of a **grounded Q&A (RAG) service** for the fictional company Kestrel Logic. It answers questions from a tenant's documents, cites its sources, refuses when evidence is weak, and tracks latency, tokens, and cost per request.

It is designed to be read and extended: the LLM and retrieval layers sit behind small interfaces so you can swap in Azure OpenAI and Azure AI Search without touching the pipeline.

## What it demonstrates

| Concern | Where | Notes |
|---|---|---|
| Retrieval | `retrieval.py` | In-memory BM25 with a query-term coverage score used as a confidence signal |
| Grounding | `service.py` | Answers must cite retrieved chunk IDs; invented or missing citations are suppressed |
| Abstention | `service.py` | Weak retrieval returns a refusal and **skips the LLM call**, so it costs nothing |
| Cost control | `cache.py`, `llm.py` | TTL + LRU response cache keyed by tenant, index version, and normalized question; per-request token and USD accounting |
| Tenant isolation | `service.py` | One index per tenant; re-indexing bumps a version that invalidates cached answers |
| Observability | `telemetry.py` | Request count, outcomes, cache-hit and abstain rates, p50/p95 latency, tokens, cost |
| Evaluation | `evaluation.py`, `eval/` | Golden set scoring citation accuracy, required facts, and abstain accuracy; usable as a CI gate |
| API | `server.py` | Stdlib JSON endpoint with input limits and clean error mapping |

## Quick start

Requires Python 3.11+. No runtime dependencies.

```bash
pip install -e ".[dev]"        # or just: pip install pytest
python -m pytest               # 29 tests
python -m kestrel_assist eval  # prints a JSON report; exits non-zero if the gate fails
python -m kestrel_assist serve --port 8080
```

```bash
curl -s localhost:8080/v1/ask -H 'Content-Type: application/json' \
  -d '{"tenant_id": "demo", "question": "What is the standard lead time for resin?"}'
```

Response:

```json
{
  "answer": "The standard lead time for resin from Harbor Plastics Supply is 21 days. [supplier-lead-times#0]",
  "citations": ["supplier-lead-times#0"],
  "abstained": false,
  "cached": false,
  "usage": {"input_tokens": 0, "output_tokens": 0, "cost_usd": 0.0},
  "latency_ms": 0.0
}
```

(Token, cost, and latency values vary per run.)

## Swapping in a real model

The bundled `ExtractiveFakeLLM` is a deterministic test double so the pipeline, tests, and evals run offline. To use a real provider, implement the `LLMClient` protocol in `llm.py`:

```python
class MyAzureOpenAIClient:
    model = "gpt-4o-mini"  # must exist in the pricing table

    def complete(self, system: str, user: str) -> Completion:
        ...  # call the provider, return text plus the provider's token counts
```

Then add the model's real per-token prices to `PRICING` (the values shipped are illustrative). Use `ExtractiveFakeLLM` in unit tests and run the golden set against the real client in a scheduled job, because real-model quality only shows up in real-model evals.

## Known limitations (deliberate, documented)

- Retrieval is lexical (BM25). Production systems usually add embeddings (hybrid search) and a reranker; the `BM25Index.search` signature is the seam for that.
- The cache is exact-match on a normalized question, not semantic.
- The HTTP server has no authentication, rate limiting, or TLS. Treat it as a demo behind a gateway.
- State is in memory and per process; multi-instance deployments need a shared index store and cache.
- Only prompt-level defenses against prompt injection are included; add output filtering and tool permissions before building agents on top.

## Design notes

See [`docs/design.md`](docs/design.md) for trade-offs and the runbook.
