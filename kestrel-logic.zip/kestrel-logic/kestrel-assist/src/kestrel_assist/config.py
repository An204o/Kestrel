from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    """Tunable knobs. Defaults are conservative; tune against the eval set, not by feel."""

    top_k: int = 4
    # Fraction of (non-stopword) query terms that the best chunk must contain; below this we abstain.
    min_coverage: float = 0.5
    max_question_chars: int = 2000
    chunk_max_chars: int = 600
    cache_ttl_seconds: float = 3600.0
    cache_max_entries: int = 1024

    def __post_init__(self) -> None:
        if self.top_k < 1:
            raise ValueError("top_k must be >= 1")
        if not 0.0 < self.min_coverage <= 1.0:
            raise ValueError("min_coverage must be in (0, 1]")
        if self.chunk_max_chars < 50:
            raise ValueError("chunk_max_chars must be >= 50")
