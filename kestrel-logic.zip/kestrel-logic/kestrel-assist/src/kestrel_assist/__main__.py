from __future__ import annotations

import argparse
import json
import logging
import sys

from .corpus import load_documents
from .evaluation import load_cases, run_eval
from .llm import ExtractiveFakeLLM
from .server import create_server
from .service import AssistantService

DEFAULT_TENANT = "demo"


def _build_service(corpus: str) -> AssistantService:
    service = AssistantService(ExtractiveFakeLLM())
    count = service.index_documents(DEFAULT_TENANT, load_documents(corpus))
    logging.getLogger(__name__).info("indexed %d chunks for tenant %r", count, DEFAULT_TENANT)
    return service


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="kestrel_assist")
    sub = parser.add_subparsers(dest="command", required=True)

    serve = sub.add_parser("serve", help="run the HTTP API")
    serve.add_argument("--corpus", default="eval/corpus")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8080)

    ev = sub.add_parser("eval", help="run the golden-set evaluation")
    ev.add_argument("--corpus", default="eval/corpus")
    ev.add_argument("--cases", default="eval/golden.jsonl")
    ev.add_argument("--min-citation-hit", type=float, default=0.95)
    ev.add_argument("--min-abstain", type=float, default=1.0)

    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    service = _build_service(args.corpus)

    if args.command == "serve":
        server = create_server(service, args.host, args.port)
        print(f"Serving on http://{args.host}:{args.port}  (Ctrl+C to stop)")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            server.shutdown()
        return 0

    report = run_eval(service, DEFAULT_TENANT, load_cases(args.cases))
    print(json.dumps(report, indent=2))
    passed = report["citation_hit_rate"] >= args.min_citation_hit and report["abstain_accuracy"] >= args.min_abstain
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
