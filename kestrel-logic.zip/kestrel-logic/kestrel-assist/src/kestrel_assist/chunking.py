from __future__ import annotations

import re
from collections.abc import Iterator

from .models import Chunk, Document

_PARAGRAPH_SPLIT = re.compile(r"\n\s*\n")
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")


def _split_long(paragraph: str, max_chars: int) -> Iterator[str]:
    """Split an oversized paragraph on sentence boundaries, hard-splitting only as a last resort."""
    current = ""
    for sentence in _SENTENCE_SPLIT.split(paragraph):
        while len(sentence) > max_chars:
            if current:
                yield current
                current = ""
            yield sentence[:max_chars]
            sentence = sentence[max_chars:]
        candidate = f"{current} {sentence}".strip()
        if len(candidate) > max_chars:
            yield current
            current = sentence
        else:
            current = candidate
    if current:
        yield current


def chunk_document(doc: Document, max_chars: int = 600) -> list[Chunk]:
    """Pack whole paragraphs into chunks of at most ``max_chars``.

    A heading-only paragraph is merged into the paragraph that follows it so the title stays
    attached to its content.
    """
    pieces: list[str] = []
    for para in (p.strip() for p in _PARAGRAPH_SPLIT.split(doc.text)):
        if not para:
            continue
        if len(para) > max_chars:
            pieces.extend(_split_long(para, max_chars))
        else:
            pieces.append(para)

    # One chunk per paragraph (precise citations). A heading is prepended to the paragraph after it,
    # so a chunk may exceed max_chars by at most the heading's length.
    chunks: list[str] = []
    heading = ""
    for piece in pieces:
        if piece.startswith("#") and "\n" not in piece:
            if heading:
                chunks.append(heading)
            heading = piece
            continue
        chunks.append(f"{heading}\n\n{piece}" if heading else piece)
        heading = ""
    if heading:
        chunks.append(heading)

    return [Chunk(chunk_id=f"{doc.doc_id}#{i}", doc_id=doc.doc_id, text=text) for i, text in enumerate(chunks)]
