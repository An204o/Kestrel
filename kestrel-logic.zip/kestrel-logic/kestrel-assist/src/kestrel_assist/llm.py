from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Protocol

from .retrieval import tokenize

# Illustrative USD prices per 1M tokens: (input, output). Replace with your provider's real rates.
PRICING: dict[str, tuple[float, float]] = {
    "demo-small": (0.15, 0.60),
    "demo-large": (2.50, 10.00),
}


@dataclass(frozen=True)
class Completion:
    text: str
    input_tokens: int
    output_tokens: int


class LLMClient(Protocol):
    """Provider-agnostic interface. Implement this for Azure OpenAI or any other provider."""

    model: str

    def complete(self, system: str, user: str) -> Completion: ...


def estimate_tokens(text: str) -> int:
    """Rough heuristic (~4 chars/token) for budgeting and the fake client; use the provider's counts in prod."""
    return max(1, len(text) // 4)


def compute_cost(model: str, input_tokens: int, output_tokens: int, pricing: dict[str, tuple[float, float]] = PRICING) -> float:
    in_price, out_price = pricing[model]
    return (input_tokens * in_price + output_tokens * out_price) / 1_000_000


_CONTEXT_LINE = re.compile(r"^\[(?P<id>[^\[\]]+#\d+)\]\s*(?P<body>.*)$", re.DOTALL)
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")


class ExtractiveFakeLLM:
    """Deterministic test double that follows the prompt contract used by AssistantService.

    It returns the context sentence that best overlaps the question, with a citation. This lets the
    whole pipeline (retrieval, citation checks, caching, cost accounting, evals) run offline in CI.
    """

    model = "demo-small"

    def complete(self, system: str, user: str) -> Completion:
        question = user.rsplit("Question:", 1)[-1].strip()
        q_terms = set(tokenize(question))
        context = user.split("Context:", 1)[-1].rsplit("Question:", 1)[0]
        best: tuple[int, str, str] | None = None
        for block in (b.strip() for b in context.split("\n\n---\n\n")):
            match = _CONTEXT_LINE.match(block)
            if not match:
                continue
            body = " ".join(line for line in match["body"].splitlines() if line.strip() and not line.startswith("#"))
            for sentence in _SENTENCE_SPLIT.split(body):
                clean = sentence.strip()
                if not clean:
                    continue
                overlap = len(q_terms & set(tokenize(clean)))
                if best is None or overlap > best[0]:
                    best = (overlap, clean, match["id"])
        if best is None:
            text = "I do not have enough information to answer that."
        else:
            text = f"{best[1]} [{best[2]}]"
        return Completion(text=text, input_tokens=estimate_tokens(system + user), output_tokens=estimate_tokens(text))
