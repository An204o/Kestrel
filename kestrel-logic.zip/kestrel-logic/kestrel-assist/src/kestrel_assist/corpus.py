from __future__ import annotations

from pathlib import Path

from .models import Document


def load_documents(directory: str | Path) -> list[Document]:
    """Load every .md and .txt file in a directory as a Document (doc_id = file stem), sorted for determinism."""
    root = Path(directory)
    if not root.is_dir():
        raise FileNotFoundError(f"Corpus directory not found: {root}")
    paths = sorted(p for p in root.iterdir() if p.suffix in {".md", ".txt"})
    return [Document(doc_id=p.stem, text=p.read_text(encoding="utf-8")) for p in paths]
