from __future__ import annotations

import json
import logging
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .service import AssistantService, UnknownTenantError

log = logging.getLogger(__name__)
MAX_BODY_BYTES = 64 * 1024


def create_server(service: AssistantService, host: str = "127.0.0.1", port: int = 8080) -> ThreadingHTTPServer:
    """Minimal stdlib JSON API. For production, put this behind a real framework, authn/z, and a gateway.

    POST /v1/ask   {"tenant_id": str, "question": str}
    GET  /healthz
    GET  /metrics
    """

    class Handler(BaseHTTPRequestHandler):
        def _send(self, status: int, payload: dict) -> None:
            body = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:  # noqa: N802
            if self.path == "/healthz":
                self._send(200, {"status": "ok"})
            elif self.path == "/metrics":
                self._send(200, service.metrics.snapshot())
            else:
                self._send(404, {"error": "not found"})

        def do_POST(self) -> None:  # noqa: N802
            if self.path != "/v1/ask":
                self._send(404, {"error": "not found"})
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                self._send(400, {"error": "invalid Content-Length"})
                return
            if length <= 0 or length > MAX_BODY_BYTES:
                self._send(400, {"error": f"body must be 1..{MAX_BODY_BYTES} bytes"})
                return
            try:
                payload = json.loads(self.rfile.read(length))
                tenant_id, question = payload["tenant_id"], payload["question"]
                if not isinstance(tenant_id, str) or not isinstance(question, str):
                    raise TypeError
            except (json.JSONDecodeError, KeyError, TypeError):
                self._send(400, {"error": "expected JSON with string fields tenant_id and question"})
                return
            try:
                answer = service.ask(tenant_id, question)
            except UnknownTenantError:
                self._send(404, {"error": "unknown tenant"})
            except ValueError as exc:
                self._send(422, {"error": str(exc)})
            except Exception:  # noqa: BLE001 - last-resort guard; details go to logs, not the client
                log.exception("unhandled error in /v1/ask")
                self._send(500, {"error": "internal error"})
            else:
                self._send(
                    200,
                    {
                        "answer": answer.text,
                        "citations": list(answer.citations),
                        "abstained": answer.abstained,
                        "cached": answer.cached,
                        "usage": {
                            "input_tokens": answer.usage.input_tokens,
                            "output_tokens": answer.usage.output_tokens,
                            "cost_usd": answer.usage.cost_usd,
                        },
                        "latency_ms": round(answer.latency_ms, 3),
                    },
                )

        def log_message(self, fmt: str, *args) -> None:
            log.info("%s - %s", self.address_string(), fmt % args)

    return ThreadingHTTPServer((host, port), Handler)
