from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Document:
    doc_id: str
    text: str


@dataclass(frozen=True)
class Chunk:
    chunk_id: str  # "<doc_id>#<n>"
    doc_id: str
    text: str


@dataclass(frozen=True)
class Retrieved:
    chunk: Chunk
    score: float
    coverage: float  # fraction of query terms present in the chunk


@dataclass(frozen=True)
class Usage:
    input_tokens: int
    output_tokens: int
    cost_usd: float


@dataclass(frozen=True)
class Answer:
    text: str
    citations: tuple[str, ...]
    abstained: bool
    cached: bool
    usage: Usage
    latency_ms: float
    outcome: str  # answered | abstained_low_retrieval | abstained_ungrounded
