from __future__ import annotations

import math
import re
from collections import Counter
from collections.abc import Iterable

from .models import Chunk, Retrieved

_TOKEN = re.compile(r"[a-z0-9]+")
_STOPWORDS = frozenset(
    "a an the of to in on for and or is are was were be by with at as it its this that what which who how do "
    "does did we our your you can i from if when many much have has had there not".split()
)


def tokenize(text: str) -> list[str]:
    """Lowercase, split on non-alphanumerics, drop stopwords, and apply a light plural strip."""
    tokens = []
    for tok in _TOKEN.findall(text.lower()):
        if tok in _STOPWORDS:
            continue
        if len(tok) > 3 and tok.endswith("s") and not tok.endswith("ss"):
            tok = tok[:-1]
        tokens.append(tok)
    return tokens


class BM25Index:
    """Immutable in-memory BM25 index over chunks. Build once per tenant, query many times."""

    def __init__(self, chunks: Iterable[Chunk], k1: float = 1.5, b: float = 0.75) -> None:
        self._chunks = list(chunks)
        self._k1 = k1
        self._b = b
        self._tf = [Counter(tokenize(c.text)) for c in self._chunks]
        self._len = [sum(tf.values()) for tf in self._tf]
        self._avg_len = (sum(self._len) / len(self._len)) if self._len else 0.0
        df: Counter[str] = Counter()
        for tf in self._tf:
            df.update(tf.keys())
        n = len(self._chunks)
        self._idf = {t: math.log(1 + (n - d + 0.5) / (d + 0.5)) for t, d in df.items()}

    def __len__(self) -> int:
        return len(self._chunks)

    def search(self, query: str, k: int = 4) -> list[Retrieved]:
        terms = set(tokenize(query))
        if not terms or not self._chunks:
            return []
        results: list[Retrieved] = []
        for chunk, tf, length in zip(self._chunks, self._tf, self._len):
            score, hits = 0.0, 0
            for term in terms:
                freq = tf.get(term, 0)
                if not freq:
                    continue
                hits += 1
                norm = freq + self._k1 * (1 - self._b + self._b * length / self._avg_len)
                score += self._idf[term] * freq * (self._k1 + 1) / norm
            if hits:
                results.append(Retrieved(chunk=chunk, score=score, coverage=hits / len(terms)))
        results.sort(key=lambda r: (-r.score, r.chunk.chunk_id))
        return results[:k]
