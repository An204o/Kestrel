from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from .service import AssistantService
from .telemetry import percentile


@dataclass(frozen=True)
class EvalCase:
    id: str
    question: str
    expect_abstain: bool = False
    expected_doc: str | None = None  # a citation must come from this document
    must_contain: str | None = None  # case-insensitive substring required in the answer


def load_cases(path: str | Path) -> list[EvalCase]:
    cases = []
    for line_no, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            cases.append(EvalCase(**json.loads(line)))
        except (json.JSONDecodeError, TypeError) as exc:
            raise ValueError(f"{path}:{line_no}: invalid eval case ({exc})") from exc
    return cases


def run_eval(service: AssistantService, tenant_id: str, cases: list[EvalCase]) -> dict:
    """Score the service on a golden set.

    - citation_hit_rate: answerable cases whose citations include the expected document
    - answer_contains_rate: answerable cases whose answer contains the required fact
    - abstain_accuracy: unanswerable cases correctly refused (a wrong answer here is a hallucination)
    """
    answerable = [c for c in cases if not c.expect_abstain]
    unanswerable = [c for c in cases if c.expect_abstain]
    cite_hits = contain_hits = correct_abstains = 0
    failures: list[dict] = []
    latencies: list[float] = []
    cost = 0.0

    for case in cases:
        # Use a fresh service per eval run: cached answers would mask pipeline regressions.
        answer = service.ask(tenant_id, case.question)
        latencies.append(answer.latency_ms)
        cost += answer.usage.cost_usd
        if case.expect_abstain:
            if answer.abstained:
                correct_abstains += 1
            else:
                failures.append({"id": case.id, "reason": "should have abstained", "answer": answer.text})
            continue
        cited_docs = {c.split("#", 1)[0] for c in answer.citations}
        ok_cite = (not case.expected_doc) or case.expected_doc in cited_docs
        ok_text = (not case.must_contain) or case.must_contain.lower() in answer.text.lower()
        cite_hits += ok_cite and not answer.abstained
        contain_hits += ok_text and not answer.abstained
        if answer.abstained or not (ok_cite and ok_text):
            failures.append({"id": case.id, "reason": "wrong or missing answer", "answer": answer.text, "citations": list(answer.citations)})

    lat = sorted(latencies)
    return {
        "cases": len(cases),
        "citation_hit_rate": cite_hits / len(answerable) if answerable else 1.0,
        "answer_contains_rate": contain_hits / len(answerable) if answerable else 1.0,
        "abstain_accuracy": correct_abstains / len(unanswerable) if unanswerable else 1.0,
        "latency_ms_p50": round(percentile(lat, 50), 3),
        "latency_ms_p95": round(percentile(lat, 95), 3),
        "total_cost_usd": round(cost, 6),
        "failures": failures,
    }
