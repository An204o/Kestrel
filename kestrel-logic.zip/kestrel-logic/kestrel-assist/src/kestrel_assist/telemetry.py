from __future__ import annotations

import math
import threading
from collections import Counter


def percentile(sorted_values: list[float], pct: float) -> float:
    """Nearest-rank percentile of an already-sorted list; 0.0 for empty input."""
    if not sorted_values:
        return 0.0
    rank = max(1, math.ceil(pct / 100 * len(sorted_values)))
    return sorted_values[rank - 1]


class Metrics:
    """In-process request metrics. In production, export these to your metrics backend instead."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._latencies: list[float] = []
        self._outcomes: Counter[str] = Counter()
        self._cache_hits = 0
        self._requests = 0
        self._input_tokens = 0
        self._output_tokens = 0
        self._cost_usd = 0.0

    def record(
        self,
        *,
        outcome: str,
        latency_ms: float,
        cached: bool,
        input_tokens: int = 0,
        output_tokens: int = 0,
        cost_usd: float = 0.0,
    ) -> None:
        with self._lock:
            self._requests += 1
            self._outcomes[outcome] += 1
            self._latencies.append(latency_ms)
            self._cache_hits += int(cached)
            self._input_tokens += input_tokens
            self._output_tokens += output_tokens
            self._cost_usd += cost_usd

    def snapshot(self) -> dict:
        with self._lock:
            lat = sorted(self._latencies)
            n = self._requests
            abstained = sum(v for k, v in self._outcomes.items() if k.startswith("abstained"))
            return {
                "requests": n,
                "outcomes": dict(self._outcomes),
                "cache_hit_rate": (self._cache_hits / n) if n else 0.0,
                "abstain_rate": (abstained / n) if n else 0.0,
                "latency_ms_p50": percentile(lat, 50),
                "latency_ms_p95": percentile(lat, 95),
                "input_tokens": self._input_tokens,
                "output_tokens": self._output_tokens,
                "cost_usd": round(self._cost_usd, 6),
                "avg_cost_usd_per_request": round(self._cost_usd / n, 8) if n else 0.0,
            }
